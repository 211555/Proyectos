#include <iostream>
#include <math.h>
#include <iomanip>
#define PRECISION 6
 using namespace std;
void Muestra( double a, double b);
double f( double x);
double f2( double x);
double f3(double x);

int main() {
 int menu;
 double a, b, tolerancia;


 do{
     cout << " -------------------PROYECTO INTERMEDIO : METODO DE BISECCION------------------------ "<< endl;
     cout << " --------------------------------Matematicas II--------------------------------------" << endl;
     cout << " -----------------------------------------" << endl;
     cout << " ---------------------------Zaira Isabel Martinez Chavez-----------------------------" << endl;
     cout << " -------------------------------------------------------------------------------------" << endl;
     cout << endl;
     cout << " ********************************Funciones******************************************* " << endl;
     cout << " Funcion 1 .-  2(x^3) - 7(x^2) + 8x - 3 " << endl;
     cout << " Funcion 2 .- 6(x^3)+ 7(x^2) + 9x + 2 " << endl;
     cout << " Funcion 3.- 1(x^3)+ 3 (x^2) - 4x-12 " << endl;
     cout << " Salir " << endl;
     cout << endl;
     cout << " Seleccione la opcion que desea. " << endl;
     cin >> menu;

     switch ( menu){

         case 1 : {
             cout << setprecision(PRECISION);
             cout << " Funcion 1 .-  2x^3 - 7x^2 + 8 x - 3 " << endl;
             cout << " Digite el valor de a " << endl;
             cin >> a;
             cout << " Digite el valor de b " << endl;
             cin >> b;
             Muestra(a,b);
             cout << " Escoja un intervalo adecuado "<< endl;
             cout << " a = " << endl;
             cin >> a;
             cout << " b = " << endl;
             cin >> b;

              double pm; // punto medio del intervalo

              if ( f(a) * f(b) > 0 ){
                  cout << " No se puede aplicar el metodo de la biseccion " << endl;
                  cout << " Por que f( " << a <<") y f(" << b  << ") tienen el mismo signo" << endl;
              } else { cout << "tolerancia " << endl;
                  cin >> tolerancia;
                  cout << "a\tb\tm\tf(a)\t\tf(b)\t\f(m)" << endl;
                  do{
                      pm = ( a + b ) / 2;
                      cout << a << " \t\t\t\t\t" << b << "\t\t\t\t\t" << pm << "\t\t\t\t\t" << f(a) << f(b)<< "\t\t\t\t\t"<< f(pm)<< endl;
                      if(abs(f(pm)) <tolerancia){
                          cout << " Una tolerancia de   " << tolerancia << " la raiz de f(a) es : "<<  pm << endl;
                          break;
                      }else{
                        if(f(pm)* f(a) > 0 ){
                              a = pm;
                          }else if(f(pm) * f(b) > 0){
                              b = pm;
                            }
                      }
                  }while( 1);
     }
             break;
         }

             case 2 : {

                 cout << setprecision(PRECISION);
                 cout << " ----------------Funcion 2 .- 6x^3 + 7x^2 + 9x + 2 ----------------" << endl;
                 cout << " Digite el valor de a " << endl;
                 cin >> a;
                 cout << " Digite el valor de b " << endl;
                 cin >> b;
                 Muestra(a,b);
                 cout << " Escoja un intervalo adecuado "<< endl;
                 cout << " a = " << endl;
                 cin >> a;
                 cout << " b = " << endl;
                 cin >> b;

                 double pm; // punto medio del intervalo

                 if ( f(a) * f(b) > 0 ){
                     cout << " No se puede aplicar el metodo de la biseccion " << endl;
                     cout << " Por que f( " << a <<") y f(" << b  << ") tienen el mismo signo" << endl;
                 } else { cout << "  una tolerancia de " << endl;
                     cin >> tolerancia;
                     cout << "a\tb\tm\tf(a)\t\tf(b)\t\f(m)" << endl;
                     do{
                         pm = ( a + b ) / 2.0 ;
                         cout << a << " \t\t\t\t\t" << b << "\t" << pm << "\t\t\t\t\t" << f(a) << f(b)<< "\t\t\t\t\t"<< f(pm)<< endl;
                         if(abs(f(pm)) <= tolerancia){
                             cout << " el intervalo  de  " <<  tolerancia << " la raiz de f es : " << pm << endl;
                             break;
                         }else {
                             if (f(pm)* f(a) > 0 ){
                                 a = pm;
                             }else if (f(pm) * f (b) > 0){
                                 b = pm;
                             }
                         }


                     }while(1 );
                 }
                 break;
             }
             case 3 : {
                 cout << setprecision(PRECISION);
                 cout << "----------------- Funcion 3.- 1(x^3)+ 3 (x^2) - 4x-12 ---------------" << endl;
                 cout << endl;
                 cout << " Digite el valor de a " << endl;
                 cin >> a;
                 cout << " Digite el valor de b " << endl;
                 cin >> b;
                 Muestra(a,b);
                 cout << " Escoja un intervalo adecuado "<< endl;
                 cout << " a = " << endl;
                 cin >> a;
                 cout << " b = " << endl;
                 cin >> b;

                 double pm; // punto medio del intervalo

                 if ( f(a) * f(b) > 0 ){
                     cout << " No se puede aplicar el metodo de la biseccion " << endl;
                     cout << " Por que f( " << a <<") y f(" << b  << ") tienen el mismo signo" << endl;
                 } else { cout << " una tolerancia de " << endl;
                     cin >> tolerancia;
                     cout << "a\tb\tx\tf(a)\t\tf(b)\t\f(x)" << endl;
                     do{
                         pm = ( a + b ) / 2.0 ;
                         cout << a << " \t\t\t\t " << b << "\t\t\t\t" << pm << "\t\t\t" << f(a) << f(b)<< "\t\t\t\t"<< f(pm)<< endl;
                         if(abs(f(pm)) <= tolerancia){
                             cout << " el intervalo  de  " << tolerancia << " la raiz de f es : "  << pm << endl;
                             break;
                         }else {
                             if (f(pm)* f (a) > 0 ){
                                 a = pm;
                             }else if (f(pm) * f (b) > 0){
                                 b = pm;
                             }
                         }


                     }while ( 1);



             }
            break;
             }
         default:
             break;

 }
}while (menu!= 3);
}
#define INTERVALOS 10
 void Muestra( double a, double  b){
    int puntos = INTERVALOS + 1 ;

    double ancho = (b - a)/ INTERVALOS;
        cout << "\n\tx\tf(x)" << endl;
     for (int i = 0; i < puntos ; ++i) {
         cout << " \t " << a << "\t" << f(a) << endl;
         a = a + ancho;
     }

}
 double f(double x){
     return (2*pow(x, 3))- (7*pow(x,2))+ 8*x -3;
}
double f2( double x){
    return (6*pow(x,3))+(7*pow(x,2))+ 9*x+ 2;
}
double f3(double x){
    (1*pow(x,3))+(3*pow(x,2))- 4*x-12;
}
