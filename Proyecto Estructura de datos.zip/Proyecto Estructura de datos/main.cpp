#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include<time.h>
#include <conio.h>

using namespace std;

struct jugadores{
    char equipo[50];
    char nombre[50];
    int numero;
    int Partidos_jugados;
    int goles_anotados;
} jugadores;

struct Nodo{
    struct jugadores * jugador;
    struct Nodo*link;
}Nodo;
struct partidos {
    string fecha;
    string hora;
    string lugar;
    string equipo1;
    string equipo2;
    int puntosequipo1;
    int puntosequipo2;
    partidos *link;
};
void leerEquipoArchivo( struct jugadores *,FILE*);
void leerArchivo(char*,struct Nodo **, struct Nodo **);
struct jugadores * crearE();
struct Nodo* crearNodo( struct jugadores *);
void agregarLista(struct Nodo **, struct Nodo **, struct Nodo*);
void imprimirLista(struct Nodo *, struct Nodo *);
void imprimirjugadores( struct jugadores * );

void imprimePartidos(struct  partidos *q);


int main() {
    struct Nodo *inicial, *final;
    inicial = NULL;
    final = NULL;
    struct partidos *p, *q;
    p = NULL;
    q = NULL;
    int menu;
    do {
        cout << "  --------------------------------------------------------" << endl;
        cout << " || ---------------------------------------------------| |" << endl;
        cout << " || --------- **LIGA DE CAMPEONES DE LA UEFA** --------| |" << endl;
        cout << " || -------** ZAIRA ISABEL MARTINEZ CHAVEZ**-----------| |" << endl;
        cout << " || ----------**ESTRUCTURA DE DATOS** -----------------| |" << endl;
        cout << " || ---------------------------------------------------| |" << endl;
        cout << "  --------------------------------------------------------" << endl;


        cout << " Eliga la opcion que desea " << endl;
        cout << " [1] Mostrar los equipos. " << endl;
        cout << " [2] Primer Enfrentamiento de equipos  " << endl;
        cout << " [3] Segundos Enfrentamientos " << endl;

        cin >> menu;


        switch (menu) {
            case 1: {
                int menu;
                do {

                    cout << " Eliga la opcion que desea: " << endl;
                    cout << " [1] GRUPO A " << endl;
                    cout << " [2] GRUPO B " << endl;
                    cout << " [3] GRUPO C " << endl;
                    cout << " [4] GRUPO D " << endl;
                    cout << "[5] SALIR " << endl;
                    cin >> menu;
                    switch (menu) {
                        case 1 : {
                            cout << "  EL GRUPO A ES : " << endl;
                            cout << " *********************************************" << endl;
                            leerArchivo("Dortmund.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << " *********************************************" << endl;
                            leerArchivo("Atletico.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << " ***********************************************" << endl;
                            leerArchivo("Monaco.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << " ***********************************************" << endl;
                            leerArchivo("Club.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                        }
                            break;
                        case 2: {
                            cout << " EL GRUPO B ES : " << endl;
                            cout << " **************************************************" << endl;
                            leerArchivo("barcelona.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << " ***************************************************" << endl;
                            leerArchivo("Tottenham.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << "*******************************************************" << endl;
                            leerArchivo("Inter.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << " *******************************************************" << endl;
                            leerArchivo("PSV.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                        }
                            break;
                        case 3: {
                            cout << " EL GRUPO C ES : " << endl;
                            cout << " *******************************************************" << endl;
                            leerArchivo("PSG.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout <<"**********************************************************" << endl;
                            leerArchivo("Liverpool.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << " ********************************************************" << endl;
                            leerArchivo("Napoli.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << " ***********************************************************" << endl;
                            leerArchivo("Estrella.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                        }
                            break;
                        case 4: {
                            cout << " EL GRUPO D ES : " << endl;
                            cout << " **********************************************************" << endl;
                            leerArchivo("Porto.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << " ***********************************************************"<< endl;
                            leerArchivo("Schalke.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << "************************************************************" << endl;
                            leerArchivo("Manchester.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                            cout << " ***************************************************************" << endl;
                            leerArchivo("Moscu.txt", &inicial, &final);
                            imprimirLista(inicial, final);
                        }
                            break;
                    }
                } while (menu != 5);
            }
                break;
            case 2: {

                int menu;
                do {
                    cout << " [1] Enfrentamientos Grupo A " << endl;
                    cout << " [2]  Enfrentamientos Grupo B" << endl;
                    cout << " [3] Efrentamientos Grupo C" << endl;
                    cout << " [4] Enfrentamientos Grupo D " << endl;
                    cin >> menu;

                    switch (menu) {
                        case 1: {
                            int i;
                            cout << " ---------------------------------" << endl;
                            cout << " ||   Enfrentamientos grupo A    ||" << endl;
                            cout << " ||        Equipos :             ||" << endl;
                            cout << " ||     DORTMUND                 ||" << endl;
                            cout << " ||          ATLETICO            || " << endl;
                            cout << " ||          MONACO              ||" << endl;
                            cout << " ||                CLUB BRUJAS   ||" << endl;
                            cout << "  ---------------------------------" << endl;
                            for (int i = 0; i < 2; i++) {
                                q = new struct partidos;
                                cout << " ------------------------------------------------" << endl;
                                cout << " Digite la Fecha del encuentro por dia mes y año  6 digitos" << endl;
                                cin >> q->fecha;
                                cout <<" Hora del encuentro " << endl;
                                cin >> q->hora;
                                cout << "Lugar del encuentro" << endl;
                                cin >> q->lugar;
                                cout << endl << endl;
                                cout << "Nombre del equipo 1 " << endl;
                                cin >> q->equipo1;
                                cout << endl << endl;
                                cout << "Nombre  del equipo 2" << endl;
                                cin >> q->equipo2;
                                cout << endl << endl;
                                cout << "Puntos del equipo 1" << endl;
                                cin >> q->puntosequipo1;
                                cout << endl << endl;
                                cout << "Puntos equipo 2" << endl;
                                cin >> q->puntosequipo2;
                                q->link = p;
                                p = q;
                                imprimePartidos(q);

                            }


                        }
                            break;
                        case 2: {

                            cout << " ---------------------------------" << endl;
                            cout << " ||   Enfrentamientos grupo B    ||" << endl;
                            cout << " ||        Equipos :             ||" << endl;
                            cout << " ||     BARCELONA                ||" << endl;
                            cout << " ||          TOTTENHAM           || " << endl;
                            cout << " ||          INTER               ||" << endl;
                            cout << " ||               PSV            ||" << endl;
                            cout << "  ---------------------------------" << endl;
                            for (int i = 0; i < 2; i++) {
                                q = new struct partidos;
                                cout << "-------------------------------------------------" << endl;
                                cout << " Digite la Fecha del encuentro por dia mes y año  6 digitos" << endl;
                                cin >> q->fecha;
                                cout <<" Hora del encuentro"<< endl;
                                cin >> q->hora;
                                cout << "Lugar del encuentro" << endl;
                                cin >> q->lugar;
                                cout << endl << endl;
                                cout << "Nombre del equipo 1 " << endl;
                                cin >> q->equipo1;
                                cout << endl << endl;
                                cout << "Nombre  del equipo 2" << endl;
                                cin >> q->equipo2;
                                cout << endl << endl;
                                cout << "Puntos del equipo 1" << endl;
                                cin >> q->puntosequipo1;
                                cout << endl << endl;
                                cout << "Puntos equipo 2" << endl;
                                cin >> q->puntosequipo2;
                                q->link = p;
                                p = q;
                                imprimePartidos(q);
                            }
                        }
                            break;
                        case 3: {
                            cout << " ---------------------------------" << endl;
                            cout << " ||   Enfrentamientos grupo C    ||" << endl;
                            cout << " ||        Equipos :             ||" << endl;
                            cout << " ||     PSG                      ||" << endl;
                            cout << " ||             LIVERPOOL        || " << endl;
                            cout << " ||        NAPOLI                ||" << endl;
                            cout << " ||            ESTRELLA ROJA     ||" << endl;
                            cout << "  ---------------------------------" << endl;
                            for (int i = 0; i < 2; i++) {
                                q = new struct partidos;
                                cout << " ----------------------------------------------" << endl;
                                cout << " Digite la Fecha del encuentro por dia mes y año  6 digitos" << endl;
                                cin >> q->fecha;
                                cout << " Hora del encuentro " <<  endl;
                                cin >> q->hora;
                                cout << "Lugar del encuentro" << endl;
                                cin >> q->lugar;
                                cout << endl << endl;
                                cout << "Nombre del equipo 1 " << endl;
                                cin >> q->equipo1;
                                cout << endl << endl;
                                cout << "Nombre  del equipo 2" << endl;
                                cin >> q->equipo2;
                                cout << endl << endl;
                                cout << "Puntos del equipo 1" << endl;
                                cin >> q->puntosequipo1;
                                cout << endl << endl;
                                cout << "Puntos equipo 2" << endl;
                                cin >> q->puntosequipo2;
                                q->link = p;
                                p = q;
                                imprimePartidos(q);
                            }
                        }
                            break;
                        case 4: {
                            cout << " ---------------------------------" << endl;
                            cout << " ||   Enfrentamientos grupo D   ||" << endl;
                            cout << " ||        Equipos :             ||" << endl;
                            cout << " ||     PORTO                    ||" << endl;
                            cout << " ||             MANCHESTER       || " << endl;
                            cout << " ||        SCHALKE               ||" << endl;
                            cout << " ||            MOSCU             ||" << endl;
                            cout << "  ---------------------------------" << endl;
                            cout << "Enfrentamientos Grupo D  " << endl;
                            cout << " Equipos : " << endl;
                            cout << " Porto " << endl;
                            cout << "Manchester  " << endl;
                            cout << " Schalke " << endl;
                            cout << " Moscu " << endl;
                            for (int i = 0; i < 2; i++) {
                                q = new struct partidos;
                                cout << " ----------------------------------------------------" << endl;
                                cout << " Digite la Fecha del encuentro por dia mes y año  6 digitos" << endl;
                                cin >> q->fecha;
                                cout <<" Dame la Hora del Encuentro " << endl;
                                cin >> q->hora;
                                cout << "Lugar del encuentro" << endl;
                                cin >> q->lugar;
                                cout << endl << endl;
                                cout << "Nombre del equipo 1 " << endl;
                                cin >> q->equipo1;
                                cout << endl << endl;
                                cout << "Nombre  del equipo 2" << endl;
                                cin >> q->equipo2;
                                cout << endl << endl;
                                cout << "Puntos del equipo 1" << endl;
                                cin >> q->puntosequipo1;
                                cout << endl << endl;
                                cout << "Puntos equipo 2" << endl;
                                cin >> q->puntosequipo2;
                                q->link = p;
                                p = q;
                                imprimePartidos(q);

                            }
                            break;
                            default:
                                break;
                        }

                    }
                } while (menu != 4);
                break;
                case 3:{
                    cout << " Equipos que pasan a la siguiente ronda " << endl;
                }
            }
        }

    }while (menu != 2);
}
void leerEquipoArchivo( struct  jugadores *equipo, FILE *archivo){
    fgets(equipo->equipo,50,archivo);
    fgets(equipo->nombre,50,archivo);
    fscanf(archivo,"%d",&equipo->numero);
    fscanf(archivo,"%d", &equipo->Partidos_jugados);
    fgetc(archivo);
    fscanf(archivo,"%d", &equipo->goles_anotados);
    fgetc(archivo);
    fgetc(archivo);
    fgetc(archivo);

}
void leerArchivo(char *ruta, struct Nodo **inicial_dir, struct Nodo ** final_dir){
    struct jugadores *nuevoEquipo;
    struct  Nodo *nuevoNodo;
    FILE *archivo;
    int n,i;

    archivo = fopen(ruta, "r");
    fscanf(archivo,"%d",&n);

    for (i = 0; i < 18; i++) {

        nuevoEquipo = crearE();
        leerEquipoArchivo(nuevoEquipo,archivo);

        nuevoNodo = crearNodo(nuevoEquipo);
        agregarLista(inicial_dir,final_dir,nuevoNodo);

    }
    fclose(archivo);
}
struct jugadores* crearE()
{
    struct jugadores *nuevoEquipo;
    nuevoEquipo=(struct jugadores *) malloc(sizeof(struct jugadores));
    return nuevoEquipo;
}
struct Nodo* crearNodo( struct jugadores *equipo){
    struct Nodo * nuevoNodo;
    nuevoNodo = new struct Nodo;
    nuevoNodo->jugador = equipo;
    nuevoNodo->link = NULL;

    return nuevoNodo;
}
void agregarLista(struct Nodo ** inicial, struct Nodo ** final, struct Nodo * nuevo ){
    if ( * inicial == NULL)
    {
        *inicial = nuevo;
        * final = nuevo;
    }
    else{
        (*final)->link = nuevo;
        *final = nuevo;

    }
}
void imprimirLista(struct Nodo *inicial, struct Nodo *final){
    struct Nodo *actual;
    actual = inicial;
    while (actual!= NULL)
    {
        imprimirjugadores( actual->jugador);
        actual = actual->link;

    }
}
void imprimirjugadores( struct jugadores * equipo ){
    int i = 0;

    cout << "El equipo es :" << equipo->equipo << endl;
    cout << "El nombre del jugador es :"<< equipo->nombre << endl;
    cout << "El numero del jugador es :" << equipo->numero << endl;
    cout << " Los partidos jugados son :"<< equipo->Partidos_jugados << endl;
    cout << " Los goles del jugador fueron :" << equipo->goles_anotados << endl;
}

void imprimePartidos(struct partidos * q) {
    int i = 1;
    while (q != NULL) {
        cout << " Partido " << i << endl;
        cout << " La fecha del enfrentamiento es  : " << q->fecha << endl;
        cout << " La hora del encuentro es : " << q->hora << endl;
        cout << " El lugar del enfrentamiento es : " << q->lugar << endl;
        cout << "El codigo d equipo dos es  : " << q->equipo1 << endl;
        cout << " El codigo del equipo dos es : " << q->equipo2 << endl;
        cout << " Los puntos del equipo 1 del enfrentamiento son :" << q->puntosequipo1 << endl;
        cout << " Los puntos del equipo 2 del enfrentamiento son : " << q->puntosequipo2 << endl;
        if ((q->puntosequipo1 >= q->puntosequipo2)) {
            cout << " el ganador es : " << q->equipo1 << endl;
        }
        else{
            cout << " El ganador es : " <<  q->equipo2 << endl;
        }
        q = q->link;
        i++;
    }

}